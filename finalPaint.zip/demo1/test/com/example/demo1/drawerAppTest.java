package com.example.demo1;

import com.sun.tools.javac.Main;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ColorPicker;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.paint.Color;
import javafx.stage.Stage;



import java.util.Objects;

public abstract class drawerAppTest  {
/*
    @Override
    public void start (Stage stage) throws Exception {
        Parent mainNode = FXMLLoader.load(drawerApp.class.getResource("hello-view.fxml"));

        stage.setScene(new Scene(mainNode));
        stage.show();
        stage.toFront();
    }

    @Before
    public void setUp () throws Exception {
    }

    @After
    public void tearDown () throws Exception {
        FxToolkit.hideStage();
        release(new KeyCode[]{});
        release(new MouseButton[]{});
    }

    @Test
    public void testCircle () {
        clickOn("#fontSize");
        write("10");
        clickOn("#circleTool").drag("#circleTool").dropTo(2,2);
    }

    @Test
    public void testRectangle () {
        clickOn("#fontSize");
        write("10");
        clickOn("#rectTool").drag("#rectTool").bounds(2,2,2,2);
    }

    @Test
    public void testLine () {
        clickOn("#fontSize");
        write("10");
        clickOn("#lineTool").drag("#lineTool").bounds(2,2,5,5);
    }

*/
}